"""
Blind Minimization Evaluator — No knowledge of the true global minimum.

KEY DESIGN PRINCIPLE:
  The standard function_minimization evaluator cheats: it knows the exact
  coordinates of the global minimum and scores programs by how close they get.

  This evaluator uses a DYNAMIC BASELINE instead:
    - Score = how much better you are than the population's current best.
    - No hardcoded target coordinates needed.
    - Works for ANY user-defined target function.

SCORING FORMULA (from the lab instructions):
    improvement = CURRENT_BEST - new_value   (positive = improvement)
    score = 0.5 + tanh(improvement * 5)      (squashed to 0..1 range)

  First ever run: score = 0.5 (neutral starting point, no baseline yet).
  Gets better than best: score > 0.5 (rewarded).
  Gets worse than best:  score < 0.5 (penalized).
  The baseline is updated whenever a new record is set.
"""

import importlib.util
import numpy as np
import time
import concurrent.futures
import traceback
import json
import os
from openevolve.evaluation_result import EvaluationResult


# =====================================================================
# DYNAMIC BASELINE — persisted to a file so it survives across evaluations
# within a single OpenEvolve run (each call to evaluate() is a new process).
# =====================================================================
BASELINE_FILE = os.path.join(os.path.dirname(__file__), "_blind_baseline.json")


def _load_baseline():
    """Load the current best value from disk (or None if first run)."""
    if os.path.exists(BASELINE_FILE):
        try:
            with open(BASELINE_FILE, "r") as f:
                data = json.load(f)
                return data.get("best_value", None)
        except Exception:
            return None
    return None


def _save_baseline(value):
    """Persist the new best value to disk."""
    try:
        with open(BASELINE_FILE, "w") as f:
            json.dump({"best_value": float(value)}, f)
    except Exception as e:
        print(f"Warning: Could not save baseline: {e}")


# =====================================================================
# TIMEOUT HELPER — same pattern as the original evaluator
# =====================================================================
def run_with_timeout(func, args=(), kwargs={}, timeout_seconds=5):
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(func, *args, **kwargs)
        try:
            return future.result(timeout=timeout_seconds)
        except concurrent.futures.TimeoutError:
            raise TimeoutError(f"Function timed out after {timeout_seconds} seconds")


def safe_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


# =====================================================================
# MAIN EVALUATE FUNCTION
# =====================================================================
def evaluate(program_path):
    """
    Score a candidate program using a dynamic relative baseline.

    Instead of comparing against a known global minimum, we compare against
    the best value seen so far across all evaluations in this evolution run.

    Returns:
        EvaluationResult with metrics:
          - combined_score  : primary metric (0..1, higher = better)
          - best_value      : the function value found this run
          - improvement     : raw improvement over current baseline
          - reliability     : fraction of trials that succeeded
    """
    # --- Load baseline ---
    current_best = _load_baseline()

    try:
        # --- Load the evolved program ---
        spec = importlib.util.spec_from_file_location("program", program_path)
        program = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(program)

        if not hasattr(program, "run_search"):
            return EvaluationResult(
                metrics={"combined_score": 0.0, "error": "Missing run_search function"},
                artifacts={"suggestion": "Program must define a run_search() returning (x, y, value)."},
            )

        # --- Run multiple trials for reliability ---
        NUM_TRIALS = 5
        values = []
        success_count = 0

        for trial in range(NUM_TRIALS):
            try:
                result = run_with_timeout(program.run_search, timeout_seconds=5)

                if not isinstance(result, tuple):
                    print(f"Trial {trial}: Expected tuple, got {type(result)}")
                    continue

                if len(result) == 3:
                    x, y, value = result
                elif len(result) == 2:
                    x, y = result
                    # Fallback: calculate the value ourselves (mirrors original evaluator pattern)
                    value = np.sin(x) * np.cos(y) + np.sin(x * y) + (x**2 + y**2) / 20
                else:
                    print(f"Trial {trial}: Unexpected tuple length {len(result)}")
                    continue

                x, y, value = safe_float(x), safe_float(y), safe_float(value)

                if any(np.isnan(v) or np.isinf(v) for v in [x, y, value]):
                    print(f"Trial {trial}: NaN/Inf in result, skipping")
                    continue

                values.append(value)
                success_count += 1

            except TimeoutError as e:
                print(f"Trial {trial}: {e}")
            except Exception as e:
                print(f"Trial {trial}: Error — {e}")
                print(traceback.format_exc())

        # --- All trials failed ---
        if success_count == 0:
            return EvaluationResult(
                metrics={
                    "combined_score": 0.0,
                    "reliability": 0.0,
                    "error": "All trials failed",
                },
                artifacts={
                    "suggestion": "Check for infinite loops, crashes, or wrong return format."
                },
            )

        # --- Best value found this evaluation ---
        best_this_run = float(np.min(values))
        reliability = float(success_count / NUM_TRIALS)

        # ---------------------------------------------------------------
        # DYNAMIC BASELINE SCORING (the key innovation of blind evaluation)
        # ---------------------------------------------------------------
        if current_best is None:
            # First ever program — no baseline yet, give a neutral score
            combined_score = 0.5
            improvement = 0.0
            baseline_note = "First evaluation — baseline initialized."
        else:
            # improvement > 0  → this run beat the current best (rewarded)
            # improvement < 0  → this run is worse than current best (penalized)
            improvement = float(current_best - best_this_run)
            combined_score = float(0.5 + np.tanh(improvement * 5))
            baseline_note = f"Baseline was {current_best:.6f}, this run got {best_this_run:.6f}"

        # Fold in reliability (don't let flaky algorithms score well)
        # 80% from improvement score, 20% from reliability
        combined_score = float(0.8 * combined_score + 0.2 * reliability)
        combined_score = float(np.clip(combined_score, 0.0, 1.0))

        # --- Update baseline if we improved ---
        if current_best is None or best_this_run < current_best:
            _save_baseline(best_this_run)
            baseline_updated = True
        else:
            baseline_updated = False

        return EvaluationResult(
            metrics={
                "combined_score": combined_score,
                "best_value": best_this_run,
                "improvement": improvement,
                "reliability": reliability,
            },
            artifacts={
                "baseline_note": baseline_note,
                "baseline_updated": str(baseline_updated),
                "num_successful_trials": str(success_count),
                "all_values": str([round(v, 4) for v in values]),
            },
        )

    except Exception as e:
        print(f"Evaluation crashed: {e}")
        print(traceback.format_exc())
        return EvaluationResult(
            metrics={"combined_score": 0.0, "error": str(e)},
            artifacts={"full_traceback": traceback.format_exc()},
        )
